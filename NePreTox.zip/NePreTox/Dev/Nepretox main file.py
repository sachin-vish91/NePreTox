import sys
import pandas as pd
import pickle
import numpy as np
from rdkit import DataStructs
from rdkit import Chem
from rdkit.Chem import AllChem
from sklearn.model_selection import cross_val_predict
from sklearn import preprocessing
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn import model_selection
from sklearn.externals import joblib
from sklearn.neural_network import MLPClassifier
import os
os.chdir('./Dev')
#print 'step01'
p = str(sys.argv[1])
q = str(sys.argv[2])
#print 'hello'
print p
# # Input

# In[4]:

#h =raw_input("Please enter the file with SMILES: ")
g = 'nepretox database.csv' 
data = pd.read_csv(g, sep=',')

#print data.shape
data.head()
y = data.VALUES.values


# # MACCS keys calculation

# In[5]:

def GetFpArray(fps):
    fps1 = []
    for fp in fps:
        arr = np.zeros((1,))
        DataStructs.ConvertToNumpyArray(fp, arr)
        fps1.append(arr)
    X = np.asarray(fps1, dtype=np.int)
    #print X.shape
    return X


# In[6]:

names = pd.read_csv('Maccs_headers.csv', sep = ',')


Mck = []

for s in data.SMILES.values:
    m = Chem.MolFromSmiles(s)
    AllChem.Compute2DCoords(m)
    
    Mck.append(AllChem.GetMACCSKeysFingerprint(m))



# In[7]:

Mck =  (GetFpArray(Mck))
np.savetxt('Maccs_keys.csv',Mck,delimiter=',')




# In[8]:

df = pd.read_csv('Maccs_keys.csv', sep=',', names=(names))
df.head()


# In[9]:

X = np.asarray(df)
#print X.shape


# # SSS

# In[10]:

sss = StratifiedShuffleSplit(n_splits=1, test_size=0.2, random_state=0)
for train_index, test_index in sss.split(X, y):
	out = ("TRAIN:", train_index, "TEST:", test_index)
	X_tr, X_xt = X[train_index], X[test_index]
	y_tr, y_xt = y[train_index], y[test_index]
	#print X_tr.shape, X_xt.shape
	#print y_tr.shape, y_xt.shape


# # RFE Feature selection

# In[11]:

model = LogisticRegression()
rfe = RFE(model, 50)
X_rfe = rfe.fit(X_tr, y_tr)
X_tr_rfe = rfe.transform(X_tr)
X_xt_rfe = rfe.transform(X_xt)
X_tr_rfe.shape, X_xt_rfe.shape
features=np.array(list(df))
selected_features=features[rfe.get_support()]
#selected_features.tofile('Selected_features_20.txt')
selected_features


# # Validation Parameters

# In[12]:

def calc_performance(y_true, y_pred, labels=[1, 0]):
    TP=0
    FN=0
    FP=0
    TN=0
    for i in range(len(y_true)):
        if (y_true[i] == labels[0] and y_pred[i] == labels[0]): TP += 1.0
        if (y_true[i] == labels[0] and y_pred[i] == labels[1]): FN += 1.0
        if (y_true[i] == labels[1] and y_pred[i] == labels[0]): FP += 1.0
        if (y_true[i] == labels[1] and y_pred[i] == labels[1]): TN += 1.0  

    recall = TP/(TP+FN)
    specificity = TN/(TN+FP)
    try: precision = TP/(TP+FP)
    except: precision = 0
    accuracy = (TP+TN)/(TP+FP+TN+FN)
    #balanced_acc = (recall+specificity)/2.0
    try: f1_score = 2*(recall*precision)/(recall+precision)
    except: f1_score = 0
    try: mcc = (TP*TN-FP*FN)/((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN))**0.5
    except: mcc = 0
    diff = abs(recall-specificity)
    if diff < 0.005: diff = 0.005
    #balanced_classification_rate = balanced_acc
    return [ round(recall,4), round(specificity,4), 
            round(precision,4), round(accuracy,4), round(f1_score,4), round(mcc,4),int(sum(y_true)), int(len(y_true)-sum(y_true))] 


# # Model
# 

# In[13]:

skf5 = model_selection.StratifiedKFold(n_splits=5, shuffle=True, random_state=0)

temp=[]

clf = MLPClassifier(solver='adam', activation='tanh',learning_rate='constant', alpha=1e-5,hidden_layer_sizes=(15, 2), 
                    random_state=None, momentum=0.5,  validation_fraction=0.2, beta_1=0.8, beta_2=0.99999, epsilon=1e-04)

model1 = clf.fit(X_tr_rfe, y_tr)
y_pred= clf.predict(X_tr_rfe)
temp.append(['Train']+calc_performance(y_tr, y_pred))

y_pred = cross_val_predict(clf, X_tr_rfe, y_tr, cv=skf5, n_jobs=1)
temp.append(['5 fold CV']+calc_performance(y_tr, y_pred))


clf.fit(X_tr_rfe, y_tr)
y_pred = clf.predict(X_xt_rfe)
temp.append(['External Validation']+calc_performance(y_xt, y_pred))

result = pd.DataFrame(temp, columns=['dataset','Recall', 'Specificity', 'Precision', 
                                    'Accuracy', 'f1_score', 'MCC', '1s', '0s'])


# In[14]:

filename = 'finalized_model.sav'
pickle.dump(model1, open(filename, 'wb'))


# In[15]:

joblib.dump(data, "Nepretox_data.pkl")
joblib.dump(model1,"Nepretox_model.pkl")
joblib.dump(rfe, "Nepretox_selector.pkl")


# # Predict single molecule

# In[28]:

load_data = joblib.load("Nepretox_data.pkl")
load_selector = joblib.load("Nepretox_selector.pkl")
load_model = joblib.load("Nepretox_model.pkl")


# In[29]:

#a= ""
#a = raw_input("Please input the name of query molecule :")


# In[30]:

#f= (load_data[load_data['Name'] == a])




# In[41]:

'''if f.values.shape.count(1)!=0:
        user_input= pd.DataFrame(data=f,columns=['CID','Name','Nephrotoxicity', 'Values', 'InChIs', 'InChi keys', 'SMILES','References'])
        #user_input.head() 
        desc = user_input.SMILES.values
        Y = user_input.Nephrotoxicity.values
        user_input
else:'''
print 'completd...........g'
#b= [x for x in raw_input("Kindly input the Name of the molecule and SMILE notation respectively, separated by a comma(','):").split(',')]
#print b
b = (p).split(',')

user_input1 = pd.DataFrame(data=[b], columns=["Name", "SMILES"])
print 'completd...........ghgh'
user_input1.head()
desc = user_input1.SMILES.values
user_input1


# In[42]:

def GetFpArray(fps):
    fps2 = []
    for fp in fps:
        arr = np.zeros((1,))
        DataStructs.ConvertToNumpyArray(fp, arr)
        fps2.append(arr)
    X1 = np.asarray(fps2, dtype=np.int)
    #print X1.shape
    return X1


# In[43]:

names = pd.read_csv('Maccs_headers.csv', sep = ',')
Mck1 = []


for s in desc:
    m = Chem.MolFromSmiles(s)
    AllChem.Compute2DCoords(m)
    
    Mck1.append(AllChem.GetMACCSKeysFingerprint(m))


# In[44]:

Mck1 = (GetFpArray(Mck1))
np.savetxt('Maccs_keys_1.csv',Mck1,delimiter=',')

df = pd.read_csv('Maccs_keys_1.csv', sep=',', names=(names))


# In[45]:

model = LogisticRegression()
rfe = RFE(model, 50)
X_rfe = rfe.fit(X_tr, y_tr)
X_tr_rfe = rfe.transform(X_tr)
X_predict = rfe.transform(Mck1)
X_tr_rfe.shape, X_predict.shape
features=np.array(list(df))
selected_features=features[rfe.get_support()]
#selected_features.tofile('Selected_features_20.txt')
selected_features


# In[46]:

result = load_model.predict(X_predict)


# In[47]:

#print "Predicted value of query :", result[0]
print result[0]

# In[ ]:
print 'done'



# In[ ]:



